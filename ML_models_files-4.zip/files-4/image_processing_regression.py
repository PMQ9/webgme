import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import r2_score, mean_squared_error

# Data from the images
# Format: [number_of_images, time_in_minutes]
data_points = [
    [26000, 33],
    [50000, 54],
    [60000, 72]
]

# Extract features and target
X = np.array([point[0] for point in data_points]).reshape(-1, 1)
y = np.array([point[1] for point in data_points])

print("="*60)
print("IMAGE PROCESSING TIME PREDICTION - REGRESSION ANALYSIS")
print("="*60)

# ============================================
# MODEL 1: Simple Linear Regression
# ============================================
print("\n" + "="*60)
print("MODEL 1: Linear Regression (Time vs Number of Images)")
print("="*60)

model_linear = LinearRegression()
model_linear.fit(X, y)

# Predictions
y_pred_linear = model_linear.predict(X)

# Model metrics
r2_linear = r2_score(y, y_pred_linear)
rmse_linear = np.sqrt(mean_squared_error(y, y_pred_linear))

print(f"\nModel Equation: Time = {model_linear.intercept_:.4f} + {model_linear.coef_[0]:.6f} * Images")
print(f"R² Score: {r2_linear:.4f}")
print(f"RMSE: {rmse_linear:.4f} minutes")

print("\n--- Predictions on Training Data ---")
for i, (actual, pred) in enumerate(zip(y, y_pred_linear)):
    print(f"Images: {X[i][0]:>6}, Actual: {actual:.1f} min, Predicted: {pred:.1f} min, Error: {abs(actual-pred):.2f} min")

# Example predictions
print("\n--- Example Predictions for New Data ---")
test_images = [10000, 30000, 40000, 70000, 80000, 100000]
for img_count in test_images:
    pred_time = model_linear.predict([[img_count]])[0]
    print(f"{img_count:>7} images → {pred_time:.1f} minutes ({pred_time/60:.2f} hours)")

# ============================================
# MODEL 2: Polynomial Regression (Degree 2)
# ============================================
print("\n" + "="*60)
print("MODEL 2: Polynomial Regression (Degree 2)")
print("="*60)

poly_features = PolynomialFeatures(degree=2)
X_poly = poly_features.fit_transform(X)

model_poly = LinearRegression()
model_poly.fit(X_poly, y)

y_pred_poly = model_poly.predict(X_poly)

r2_poly = r2_score(y, y_pred_poly)
rmse_poly = np.sqrt(mean_squared_error(y, y_pred_poly))

print(f"\nR² Score: {r2_poly:.4f}")
print(f"RMSE: {rmse_poly:.4f} minutes")

print("\n--- Predictions on Training Data ---")
for i, (actual, pred) in enumerate(zip(y, y_pred_poly)):
    print(f"Images: {X[i][0]:>6}, Actual: {actual:.1f} min, Predicted: {pred:.1f} min, Error: {abs(actual-pred):.2f} min")

# ============================================
# VISUALIZATION
# ============================================
plt.figure(figsize=(12, 8))

# Plot 1: Linear Regression
plt.subplot(2, 1, 1)
X_range = np.linspace(X.min(), X.max() * 1.2, 100).reshape(-1, 1)
y_range_linear = model_linear.predict(X_range)

plt.scatter(X, y, color='red', s=100, label='Actual Data', zorder=3)
plt.plot(X_range, y_range_linear, color='blue', linewidth=2, label=f'Linear Fit (R²={r2_linear:.4f})')
plt.xlabel('Number of Images', fontsize=12)
plt.ylabel('Time (minutes)', fontsize=12)
plt.title('Linear Regression: Processing Time vs Number of Images', fontsize=14, fontweight='bold')
plt.grid(True, alpha=0.3)
plt.legend()

# Plot 2: Polynomial Regression
plt.subplot(2, 1, 2)
X_range_poly = poly_features.transform(X_range)
y_range_poly = model_poly.predict(X_range_poly)

plt.scatter(X, y, color='red', s=100, label='Actual Data', zorder=3)
plt.plot(X_range, y_range_poly, color='green', linewidth=2, label=f'Polynomial Fit (R²={r2_poly:.4f})')
plt.xlabel('Number of Images', fontsize=12)
plt.ylabel('Time (minutes)', fontsize=12)
plt.title('Polynomial Regression (Degree 2): Processing Time vs Number of Images', fontsize=14, fontweight='bold')
plt.grid(True, alpha=0.3)
plt.legend()

plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/regression_analysis.png', dpi=300, bbox_inches='tight')
print("\n" + "="*60)
print("Plot saved to outputs folder!")
print("="*60)

# ============================================
# PREDICTION FUNCTION
# ============================================
print("\n" + "="*60)
print("PREDICTION FUNCTION")
print("="*60)

def predict_time(num_images, model_type='linear'):
    """
    Predict processing time based on number of images
    
    Parameters:
    - num_images: int, number of images to process
    - model_type: str, 'linear' or 'polynomial'
    
    Returns:
    - predicted_time: float, estimated time in minutes
    """
    if model_type == 'linear':
        time = model_linear.predict([[num_images]])[0]
    elif model_type == 'polynomial':
        X_poly_input = poly_features.transform([[num_images]])
        time = model_poly.predict(X_poly_input)[0]
    else:
        raise ValueError("model_type must be 'linear' or 'polynomial'")
    
    return time

# Test the function
print("\nUsing the prediction function:")
test_value = 45000
print(f"For {test_value} images:")
print(f"  Linear model: {predict_time(test_value, 'linear'):.1f} minutes")
print(f"  Polynomial model: {predict_time(test_value, 'polynomial'):.1f} minutes")

# ============================================
# MODEL 3: Multi-feature model (if you have model count data)
# ============================================
print("\n" + "="*60)
print("MODEL 3: Multiple Linear Regression")
print("(Number of Models + Number of Images → Time)")
print("="*60)

# Based on your notes, it seems like you're using multiple models
# From the image, I can see:
# 2 models with 25,000 and 50,000 images = 33.5 + 54 mins
# 3 models with 26,000, 50,000, and 60,000 images = 33.5 + 54 + 72 mins

# Let's create a dataset assuming each model processes independently
# Each row: [num_models, total_images, total_time]
multi_data = [
    [1, 26000, 33],
    [1, 50000, 54],
    [1, 60000, 72],
    # If running 2 models in parallel with different image counts
    # the time would be the max of the two
    # But if running sequentially, it would be the sum
]

print("\nNote: For multiple models running sequentially,")
print("the total time is approximately the sum of individual times.")
print("\nFor parallel processing, the time would be the maximum of individual times.")

# Simple formula for sequential processing
print("\n--- Sequential Processing Formula ---")
print("Total Time ≈ Σ(Time for each model)")
print("\nExample: 2 models processing 26,000 and 50,000 images")
time_model1 = predict_time(26000, 'linear')
time_model2 = predict_time(50000, 'linear')
print(f"  Model 1 (26,000 images): {time_model1:.1f} min")
print(f"  Model 2 (50,000 images): {time_model2:.1f} min")
print(f"  Total Sequential Time: {time_model1 + time_model2:.1f} min")

print("\n" + "="*60)
print("ANALYSIS COMPLETE")
print("="*60)
