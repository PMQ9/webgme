/**
 * Simple Time Prediction Script (JavaScript Version)
 * Based on regression analysis of image processing times
 *
 * Usage:
 *    node predict_time.js
 *
 * Or import and use:
 *    const { predictProcessingTime } = require("./predict_time");
 *    const time = predictProcessingTime(50000);
 */

// ------------------------------------------------------
// Predict time for a single model
// ------------------------------------------------------
function predictProcessingTime(numImages, modelType = "linear") {
    /**
     * Predict processing time based on the number of images
     * Returns time in minutes
     */

    if (modelType === "linear") {
        // Linear model: Time = 3.2620 + 0.001097 * Images
        const intercept = 3.2620;
        const coefficient = 0.001097;
        return intercept + coefficient * numImages;

    } else if (modelType === "polynomial") {
        // Polynomial model (degree 2)
        const c0 = 3.2619607843137337;
        const c1 = 0.0010971764705882374;
        const c2 = 4.411764705882354e-10;
        return c0 + c1 * numImages + c2 * (numImages ** 2);

    } else {
        throw new Error("model_type must be 'linear' or 'polynomial'");
    }
}

// ------------------------------------------------------
// Predict time for multiple models (sequential or parallel)
// ------------------------------------------------------
function predictMultiModelTime(imageCounts, processing = "sequential") {
    const individualTimes = imageCounts.map(count =>
        predictProcessingTime(count)
    );

    let totalTime;
    if (processing === "sequential") {
        totalTime = individualTimes.reduce((acc, t) => acc + t, 0);
    } else if (processing === "parallel") {
        totalTime = Math.max(...individualTimes);
    } else {
        throw new Error("processing must be 'sequential' or 'parallel'");
    }

    return {
        total_time_minutes: totalTime,
        total_time_hours: totalTime / 60,
        individual_times: individualTimes,
        num_models: imageCounts.length,
        processing_mode: processing
    };
}

// ------------------------------------------------------
// Example Usage (if run directly)
// ------------------------------------------------------
if (require.main === module) {
    console.log("=".repeat(60));
    console.log("IMAGE PROCESSING TIME PREDICTOR (JavaScript)");
    console.log("=".repeat(60));

    // Single model predictions
    console.log("\n--- Single Model Predictions ---");
    const testCases = [10000, 26000, 40000, 50000, 60000, 80000, 100000];

    testCases.forEach(numImages => {
        const timeLinear = predictProcessingTime(numImages, "linear");
        const timePoly = predictProcessingTime(numImages, "polynomial");

        console.log(
            `${numImages.toString().padStart(7)} images → ` +
            `${timeLinear.toFixed(1)} min (linear), ` +
            `${timePoly.toFixed(1)} min (polynomial)`
        );
    });

    // Multi-model predictions
    console.log("\n--- Multi-Model Predictions ---");

    // Example 1: 2 models (26k + 50k)
    let result = predictMultiModelTime([26000, 50000], "sequential");
    console.log(`\n2 models (26k + 50k) - Sequential:`);
    console.log(`  Individual times: ${result.individual_times.map(t => t.toFixed(1))}`);
    console.log(`  Total time: ${result.total_time_minutes.toFixed(1)} min (${result.total_time_hours.toFixed(2)} hours)`);

    // Example 2: 3 models (26k + 50k + 60k)
    result = predictMultiModelTime([26000, 50000, 60000], "sequential");
    console.log(`\n3 models (26k + 50k + 60k) - Sequential:`);
    console.log(`  Individual times: ${result.individual_times.map(t => t.toFixed(1))}`);
    console.log(`  Total time: ${result.total_time_minutes.toFixed(1)} min (${result.total_time_hours.toFixed(2)} hours)`);

    // Example 3: Parallel
    result = predictMultiModelTime([26000, 50000, 60000], "parallel");
    console.log(`\n3 models (26k + 50k + 60k) - Parallel:`);
    console.log(`  Individual times: ${result.individual_times.map(t => t.toFixed(1))}`);
    console.log(`  Total time: ${result.total_time_minutes.toFixed(1)} min (${result.total_time_hours.toFixed(2)} hours)`);

    console.log("\n" + "=".repeat(60));
}

// Export functions for module use
module.exports = {
    predictProcessingTime,
    predictMultiModelTime
};