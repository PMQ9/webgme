"""
Simple Time Prediction Script
Based on regression analysis of image processing times

Usage:
    python predict_time.py
    
Or import and use the function:
    from predict_time import predict_processing_time
    time = predict_processing_time(50000)
"""

def predict_processing_time(num_images, model_type='linear'):
    """
    Predict processing time based on number of images
    
    Parameters:
    -----------
    num_images : int
        Number of images to process
    model_type : str, optional (default='linear')
        Type of regression model to use: 'linear' or 'polynomial'
    
    Returns:
    --------
    float
        Predicted processing time in minutes
    
    Models derived from data:
    - 26,000 images → 33 minutes
    - 50,000 images → 54 minutes  
    - 60,000 images → 72 minutes
    """
    
    if model_type == 'linear':
        # Linear model: Time = 3.2620 + 0.001097 * Images
        intercept = 3.2620
        coefficient = 0.001097
        time = intercept + coefficient * num_images
        
    elif model_type == 'polynomial':
        # Polynomial model (degree 2) coefficients
        # Fitted perfectly to the 3 data points
        c0 = 3.2619607843137337
        c1 = 0.0010971764705882374
        c2 = 4.411764705882354e-10
        time = c0 + c1 * num_images + c2 * (num_images ** 2)
        
    else:
        raise ValueError("model_type must be 'linear' or 'polynomial'")
    
    return time


def predict_multi_model_time(image_counts, processing='sequential'):
    """
    Predict total time when processing multiple models
    
    Parameters:
    -----------
    image_counts : list of int
        List of image counts for each model
        Example: [26000, 50000, 60000] for 3 models
    processing : str, optional (default='sequential')
        'sequential' - models run one after another (sum of times)
        'parallel' - models run simultaneously (max of times)
    
    Returns:
    --------
    dict
        Dictionary with total time and individual model times
    """
    
    individual_times = [predict_processing_time(count) for count in image_counts]
    
    if processing == 'sequential':
        total_time = sum(individual_times)
    elif processing == 'parallel':
        total_time = max(individual_times)
    else:
        raise ValueError("processing must be 'sequential' or 'parallel'")
    
    return {
        'total_time_minutes': total_time,
        'total_time_hours': total_time / 60,
        'individual_times': individual_times,
        'num_models': len(image_counts),
        'processing_mode': processing
    }


# Example usage
if __name__ == "__main__":
    print("="*60)
    print("IMAGE PROCESSING TIME PREDICTOR")
    print("="*60)
    
    # Single model predictions
    print("\n--- Single Model Predictions ---")
    test_cases = [10000, 26000, 40000, 50000, 60000, 80000, 100000]
    
    for num_images in test_cases:
        time_linear = predict_processing_time(num_images, 'linear')
        time_poly = predict_processing_time(num_images, 'polynomial')
        print(f"{num_images:>7} images → {time_linear:>6.1f} min (linear), {time_poly:>6.1f} min (polynomial)")
    
    # Multi-model predictions
    print("\n--- Multi-Model Predictions ---")
    
    # Example 1: 2 models (26k and 50k images)
    result = predict_multi_model_time([26000, 50000], 'sequential')
    print(f"\n2 models (26k + 50k images) - Sequential:")
    print(f"  Individual times: {[f'{t:.1f}' for t in result['individual_times']]} min")
    print(f"  Total time: {result['total_time_minutes']:.1f} min ({result['total_time_hours']:.2f} hours)")
    
    # Example 2: 3 models (26k, 50k, 60k images)
    result = predict_multi_model_time([26000, 50000, 60000], 'sequential')
    print(f"\n3 models (26k + 50k + 60k images) - Sequential:")
    print(f"  Individual times: {[f'{t:.1f}' for t in result['individual_times']]} min")
    print(f"  Total time: {result['total_time_minutes']:.1f} min ({result['total_time_hours']:.2f} hours)")
    
    # Example 3: Parallel processing
    result = predict_multi_model_time([26000, 50000, 60000], 'parallel')
    print(f"\n3 models (26k + 50k + 60k images) - Parallel:")
    print(f"  Individual times: {[f'{t:.1f}' for t in result['individual_times']]} min")
    print(f"  Total time: {result['total_time_minutes']:.1f} min ({result['total_time_hours']:.2f} hours)")
    
    print("\n" + "="*60)
    
    # Interactive mode
    print("\n--- Interactive Mode ---")
    try:
        user_input = input("\nEnter number of images (or press Enter to skip): ")
        if user_input.strip():
            num_images = int(user_input)
            time = predict_processing_time(num_images)
            print(f"\nPredicted time for {num_images} images: {time:.1f} minutes ({time/60:.2f} hours)")
    except (ValueError, EOFError):
        print("Skipping interactive mode.")
    
    print("\n" + "="*60)
